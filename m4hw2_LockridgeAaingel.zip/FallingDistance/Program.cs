﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 5/9/22
* CSC 153
* Aaingel L.
* Falling distance program
*/
namespace FallingDistance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter amt of seconds object has fallen:");
            double t = Double.Parse(Console.ReadLine());
            double solution = FallingDist(t);
            Console.WriteLine(solution + " meters");
            Console.ReadLine();
        }
           static public double FallingDist(double t)
        {
            double raise = 9.8 * t;
            return 0.5 * Math.Pow(raise, 2);
        }

    }
}
