﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesEmployee
{
    class Customer: Person
    {
       
        private int customerNumber;
        private bool mailList;
        public int CustomerNumber
        {
            get { return customerNumber; }
            set { customerNumber = value; }
        }
        //
        public bool MailList
        {
            get { return mailList; }
            set { mailList = value; }
        }
       
    }
}
