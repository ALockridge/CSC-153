﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 4/27/22
* CSC 153
* Aaingel L.
* class inheritance demonstration
*/

namespace ClassesEmployee
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer Object = new Customer(); //create object
            //assign values
            Object.Name = "CustomerName";
            Object.Address = "CustomerAddress";
            Object.PhoneNumber = "CustomerNumber";
            Object.CustomerNumber = 1;
            Object.MailList = true;
            //display object values
            Console.WriteLine(
                Object.Name
                + "\n"
                + Object.Address
                + "\n"
                + Object.PhoneNumber
                + "\n"
                + Object.CustomerNumber
                + "\n"
                + Object.MailList
                );
            Console.ReadLine();
        }
    }
}
